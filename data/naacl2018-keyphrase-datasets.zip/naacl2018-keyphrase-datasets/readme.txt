﻿Microblog keyphrase extraction corpus (first released on June 2018)
URL: http://ai.tencent.com/ailab/Encoding_Conversation_Context_for_Neural_Keyphrase_Extraction_from_Microblog_Posts.html

This corpus is distributed together with:

Encoding Conversation Context for Neural Keyphrase Extraction from Microblog Posts
Yingyi Zhang, Jing li, Yan Song, Chengzhi Zhang
Proceedings of the Conference of the North American Chapter of the Association for Computational Linguistics (NAACL), 2018.


==== Content ====

I. Description of the datasets
II. Contact
III. Citation
IV. LICENSE

==== I. Description of the datasets ====

There are two dataset files in this package:

1) twitter.txt
It contains Twitter conversations from TREC microblog data. The description can be found in the paper.

2) weibo.txt
It contains Weibo conversations crawled from Sina Weibo (encoded by UTF-8). The description can be found in the paper too.


>> Data structure

1) twitter.txt
	For each file, the line consists of four fields: <Conversation ID>, <Tweet ID>, <Reply To Tweet ID> and <Keyphrase>. <Reply To Tweet ID> is the parent tweet of <Tweet ID> in the conversation tree, where null values refer to root messages.
	*Fields are devided by Tab, and words in each element are divided by Space.
	*Note that we don't release the content of tweets because of Twitter’s Developer Policy (https://developer.twitter.com/en/developer-terms/agreement-and-policy).

2) weibo.txt
	For each file, the line consists of six fields: <Conversation ID>, <Weibo ID>, <Reply To Weibo ID>, <Weibo Content>, <Word Segmentation Result of Weibo Content> and <Word Segmentation Result of Keyphrase>. <Reply To Weibo ID> is the parent tweet of <Weibo ID> in the conversation tree, where null values refer to root messages.
	*Fields are devided by Tab, and words in each element are divided by Space.
	*Note that the statistics of Weibo dataset are slightly different from those described in our paper, because we removed sensitive information from the released dataset.

==== II. Contact ====

Should you have any questions, please contact ameliajli@tencent.com (Jing Li)

==== III. Citation ====

If you use or refer to our datasets, please support us by citing our paper:

@InProceedings{N18-1151,
  author = 	"Zhang, Yingyi
		and Li, Jing
		and Song, Yan
		and Zhang, Chengzhi",
  title = 	"Encoding Conversation Context for Neural Keyphrase Extraction from Microblog Posts",
  booktitle = 	"Proceedings of the 2018 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies, Volume 1 (Long Papers)",
  year = 	"2018",
  publisher = 	"Association for Computational Linguistics",
  pages = 	"1676--1686",
  location = 	"New Orleans, Louisiana",
  url = 	"http://aclweb.org/anthology/N18-1151"
}

Many thanks!


==== IV. LICENSE ====

//The accompanying dataset is released under a Creative Commons Attribution 3.0 Unported License
(http://creativecommons.org/licenses/by/3.0/).