﻿Author: Jing Li

The file data.data is the data-set for leader detection on reposting paths. Reposting paths are separated by blank lines. Each line (except for blank lines) represents one micropost in a reposting path and the first micropost of a reposting path is the root/original micropost. The format of annotated micropost is:
[LABEL] [MICROPOST] 
where [LABEL] represents whether a micropost is a leader or not, i.e. 1 for leader and 0 for follower, and [MICROPOST] is the content of the micropost.

Remark: It is clear that root are leaders (labeled by 1) according to the definition of leaders.

