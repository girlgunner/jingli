Author: Jing Li

This is the data-set used in the experiment of the paper: Li et al.:"Using Content-level Structures for Summarizing Microblog Repost Trees." EMNLP 2015. It is public only for research issues. Please don't use it for other purposes, e.g. business, politics, etc. Also, when you use it for your research work, remember to cite this work. 

The data-set of leader detection, which is in the file ``leader detection" contains the annotated microblog reposting paths with each post tagged as a leader or a follower. It can be used for training and/or testing models for leader detection. For details, please refer to the ``readme.txt" document in the file ``leader detection".

The data-set of repost tree summarization, which is in the file ``summarization" contains editorial summaries to 10 repost trees. It can be used for training and/or evaluating repost tree summarization models. For details, please refer to ``readme.txt" document in the file ``summarization". 

Remarks: microblog posts from the two data-sets are collected from Sina Weibo (http://www.weibo.com) and all messages are in Chinese encoded by UTF-8. Make sure you decode it correctly otherwise all words would be garbled. Many free software can solve the problem of encoding, such as Notepad++. We are also trying to prepare Twitter repost (retweet) tree data-set, but it is not trivial since there are some limitations in repost (retweet) tree crawling for Twitter data. If you can help prepare a data-set of Twitter, don't forget to email us :-)