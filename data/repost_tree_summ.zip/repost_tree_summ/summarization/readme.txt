﻿Author: Jing Li

This data-set is for repost tree summarization evaluation. The file ``repost trees" contain 10 repost trees about hot events taking place during Jan 2nd and Jul 28, 2014 crawled by PKUVIS toolkit (http://vis.pku.edu.cn/weibova/weiboevents/index.html). Each csv document contains detailed information of microposts in a repost tree. The detailed description of the csv files can be found at: http://vis.pku.edu.cn/weibova/weiboevents/manual#exportcsv. 

Simple descriptions of the ten repost trees are:

Tree (I).	HKU dropping out student wins the college entrance exam again.
Tree (II).	German boy complains hard schoolwork in Chinese High School.
Tree (III).	Movie Tiny Times 1.0 wins high grossing in criticism.
Tree (IV).	 ``I am A Singer'' states that singer G.E.M asking for resinging conforms to rules.
Tree (V).	Crystal Huang clarified the rumor of her derailment.
Tree (VI).	Germany routs Brazil 7:1 in World-Cup semi-final.
Tree (VII).	The pretty girl pregnant with a second baby graduated with her master degree. 
Tree (VIII).	Girls appealed for equality between men and women in college admission
Tree (IX).	Violent terrorist attack in Kunming railway station.
Tree (X).	MH17 crash killed many top HIV researchers 

Files editor 1-3 contain editorial summaries to the 10 repost trees writen by three editors. In file editor x (x=1,2,3), there are ten txt documents where XXX.txt contain the editorial summary for repost tree XXX.csv in the file ``repost tree". For example, [editor 2\\Tree (IV).txt] is the editorial summary for [repost tress\\Tree (IV).csv] writen by editor 2. To ensure the quality of reference summaries, before editors start summarizing repost trees, we extracted a list of frequent nouns from each repost tree and generalized 7 to 10 topics based on the nouns list, which provided a high-level overview of a repost tree to editors. And editors are asked to write summaries for each provided topics. In each txt document, the format of each line is as following:
【XXX】XXXXXXXXX
where the words in 【】 are topics provided to editors for helping summary writing and the text after 【】 is the summary sentences for summarizing corresponding topic.

