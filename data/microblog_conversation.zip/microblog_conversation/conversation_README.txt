Microblog conversation recommendation Corpus (first released on April 2018)
URL: http://www.ccs.neu.edu/home/luwang/

This corpus is distributed together with:

Microblog Conversation Recommendation via Joint Modeling of Topics and Discourse
Xingshan Zeng, Jing Li, Lu Wang, Nicholas Beauchamp, Sarah Shugars, Kam-Fai Wong
Proceedings of the Conference of the North American Chapter of the Association for Computational Linguistics (NAACL), 2018.


==== Content ====

I. Description of the datasets
II. Contact


==== I. Description of the datasets ====

There are two json files under directory /PATH/TO/microblog_conversation:

1) US_Election.data.json
It contains Twitter conversations related with 2016 U.S. election. The description of data collection and selection can be found in our NAACL 2018 paper.

2) TREC.data
It contains Twitter conversations from TREC microblog data. The description can be found in the paper too.


>> Data structure

For each file, each line consists of three fields: <Conversation ID>, <Tweet ID>, and <Reply To Tweet ID>, where <Reply To Tweet ID> is the parent tweet of <Tweet ID> in the conversation tree.


==== II. Contact ====

Should you have any questions, please contact luwang@ccs.neu.edu (Lu Wang).





